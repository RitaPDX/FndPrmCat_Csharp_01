﻿namespace FndPrmCat
	{
	partial class frmCatHlp
		{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
			{
			if (disposing && (components != null))
				{
				components.Dispose();
				}
			base.Dispose(disposing);
			}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
			{
			this.rtbCatHlp = new RichTextBoxEx.RichTextBoxEx();
			this.lblLine = new System.Windows.Forms.Label();
			this.btnExit = new CSharpEx.GlassButton();
			this.SuspendLayout();
			// 
			// rtbCatHlp
			// 
			this.rtbCatHlp.AcceptsTab = false;
			this.rtbCatHlp.AutoScroll = true;
			this.rtbCatHlp.AutoScrollMargin = new System.Drawing.Size(1, 1);
			this.rtbCatHlp.AutoScrollMinSize = new System.Drawing.Size(1, 1);
			this.rtbCatHlp.AutoWordSelection = true;
			this.rtbCatHlp.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.rtbCatHlp.DetectURLs = true;
			this.rtbCatHlp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.rtbCatHlp.Location = new System.Drawing.Point(4, 0);
			this.rtbCatHlp.MaximumSize = new System.Drawing.Size(505, 265);
			this.rtbCatHlp.MinimumSize = new System.Drawing.Size(505, 265);
			this.rtbCatHlp.Name = "rtbCatHlp";
			this.rtbCatHlp.ReadOnly = true;
			// 
			// 
			// 
			this.rtbCatHlp.RichTextBox.AutoWordSelection = true;
			this.rtbCatHlp.RichTextBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.rtbCatHlp.RichTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.rtbCatHlp.RichTextBox.Dock = System.Windows.Forms.DockStyle.Fill;
			this.rtbCatHlp.RichTextBox.ForeColor = System.Drawing.Color.Navy;
			this.rtbCatHlp.RichTextBox.Location = new System.Drawing.Point(0, 0);
			this.rtbCatHlp.RichTextBox.MaximumSize = new System.Drawing.Size(490, 265);
			this.rtbCatHlp.RichTextBox.MinimumSize = new System.Drawing.Size(490, 265);
			this.rtbCatHlp.RichTextBox.Name = "rtb1";
			this.rtbCatHlp.RichTextBox.ReadOnly = true;
			this.rtbCatHlp.RichTextBox.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
			this.rtbCatHlp.RichTextBox.Size = new System.Drawing.Size(490, 265);
			this.rtbCatHlp.RichTextBox.TabIndex = 1;
			this.rtbCatHlp.ShowBold = true;
			this.rtbCatHlp.ShowCenterJustify = true;
			this.rtbCatHlp.ShowColors = true;
			this.rtbCatHlp.ShowCopy = true;
			this.rtbCatHlp.ShowCut = true;
			this.rtbCatHlp.ShowFont = true;
			this.rtbCatHlp.ShowFontSize = true;
			this.rtbCatHlp.ShowItalic = true;
			this.rtbCatHlp.ShowLeftJustify = true;
			this.rtbCatHlp.ShowOpen = true;
			this.rtbCatHlp.ShowPaste = true;
			this.rtbCatHlp.ShowRedo = true;
			this.rtbCatHlp.ShowRightJustify = true;
			this.rtbCatHlp.ShowSave = true;
			this.rtbCatHlp.ShowStamp = true;
			this.rtbCatHlp.ShowStrikeout = true;
			this.rtbCatHlp.ShowToolBarText = false;
			this.rtbCatHlp.ShowUnderline = true;
			this.rtbCatHlp.ShowUndo = true;
			this.rtbCatHlp.Size = new System.Drawing.Size(505, 265);
			this.rtbCatHlp.StampAction = RichTextBoxEx.StampActions.EditedBy;
			this.rtbCatHlp.StampColor = System.Drawing.Color.Blue;
			this.rtbCatHlp.TabIndex = 2;
			// 
			// 
			// 
			this.rtbCatHlp.Toolbar.Appearance = System.Windows.Forms.ToolBarAppearance.Flat;
			this.rtbCatHlp.Toolbar.ButtonSize = new System.Drawing.Size(16, 16);
			this.rtbCatHlp.Toolbar.Divider = false;
			this.rtbCatHlp.Toolbar.DropDownArrows = true;
			this.rtbCatHlp.Toolbar.Enabled = false;
			this.rtbCatHlp.Toolbar.Location = new System.Drawing.Point(0, 0);
			this.rtbCatHlp.Toolbar.Name = "tb1";
			this.rtbCatHlp.Toolbar.ShowToolTips = true;
			this.rtbCatHlp.Toolbar.Size = new System.Drawing.Size(470, 20);
			this.rtbCatHlp.Toolbar.TabIndex = 0;
			this.rtbCatHlp.Toolbar.Visible = false;
			// 
			// lblLine
			// 
			this.lblLine.AutoSize = true;
			this.lblLine.BackColor = System.Drawing.Color.Navy;
			this.lblLine.Location = new System.Drawing.Point(0, 268);
			this.lblLine.MaximumSize = new System.Drawing.Size(525, 3);
			this.lblLine.MinimumSize = new System.Drawing.Size(525, 3);
			this.lblLine.Name = "lblLine";
			this.lblLine.Size = new System.Drawing.Size(525, 3);
			this.lblLine.TabIndex = 38;
			// 
			// btnExit
			// 
			this.btnExit.AlternativeFocusBorderColor = System.Drawing.Color.Navy;
			this.btnExit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.btnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnExit.ForeColor = System.Drawing.Color.Navy;
			this.btnExit.GlowColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.btnExit.InnerBorderColor = System.Drawing.Color.Navy;
			this.btnExit.Location = new System.Drawing.Point(434, 276);
			this.btnExit.Name = "btnExit";
			this.btnExit.OuterBorderColor = System.Drawing.Color.Navy;
			this.btnExit.ShineColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.btnExit.Size = new System.Drawing.Size(45, 30);
			this.btnExit.SpecialSymbolColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.btnExit.TabIndex = 39;
			this.btnExit.Text = "OK";
			this.btnExit.Click += new System.EventHandler(this.btnOK_Click);
			// 
			// frmCatHlp
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.ClientSize = new System.Drawing.Size(514, 311);
			this.Controls.Add(this.btnExit);
			this.Controls.Add(this.lblLine);
			this.Controls.Add(this.rtbCatHlp);
			this.ForeColor = System.Drawing.Color.Navy;
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "frmCatHlp";
			this.Text = "Help for Category  ";
			this.ResumeLayout(false);
			this.PerformLayout();

			}

		#endregion

		private System.Windows.Forms.Label lblLine;
		public RichTextBoxEx.RichTextBoxEx rtbCatHlp;
		private CSharpEx.GlassButton btnExit;
		}
	}