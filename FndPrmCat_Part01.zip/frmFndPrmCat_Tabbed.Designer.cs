﻿namespace FndPrmCat
	{
	partial class frmFndPrmCat_Tabbed
		{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose (bool disposing)
			{
			if (disposing && (components != null))
				{
				components.Dispose();
				}
			base.Dispose(disposing);
			}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent ()
			{
			this.tabFndPrms = new System.Windows.Forms.TabControl();
			this.tabCmmnPrms = new System.Windows.Forms.TabPage();
			this.tabPage2 = new System.Windows.Forms.TabPage();
			this.tabPage3 = new System.Windows.Forms.TabPage();
			this.tabPage4 = new System.Windows.Forms.TabPage();
			this.tabPage5 = new System.Windows.Forms.TabPage();
			this.tabPage6 = new System.Windows.Forms.TabPage();
			this.grpCat = new CSharpEx.GroupBoxEx();
			this.btnHlpSexy = new System.Windows.Forms.Button();
			this.btnHlpCous = new System.Windows.Forms.Button();
			this.btnHlpTrip = new System.Windows.Forms.Button();
			this.btnHlpQuin = new System.Windows.Forms.Button();
			this.btnHlpQuad = new System.Windows.Forms.Button();
			this.btnHlpSext = new System.Windows.Forms.Button();
			this.btnHlpTwin = new System.Windows.Forms.Button();
			this.radBaln = new System.Windows.Forms.RadioButton();
			this.btnHlpBiTwin = new System.Windows.Forms.Button();
			this.radNorm = new System.Windows.Forms.RadioButton();
			this.btnHlpAriProg = new System.Windows.Forms.Button();
			this.radAriProg = new System.Windows.Forms.RadioButton();
			this.btnHlpNorm = new System.Windows.Forms.Button();
			this.radBiTwn = new System.Windows.Forms.RadioButton();
			this.btnHlpSafe = new System.Windows.Forms.Button();
			this.radSafe = new System.Windows.Forms.RadioButton();
			this.btnHlpBaln = new System.Windows.Forms.Button();
			this.radCunn = new System.Windows.Forms.RadioButton();
			this.btnHlpCunn = new System.Windows.Forms.Button();
			this.radSoph = new System.Windows.Forms.RadioButton();
			this.btnHlpSoph = new System.Windows.Forms.Button();
			this.radTrip = new System.Windows.Forms.RadioButton();
			this.radTwin = new System.Windows.Forms.RadioButton();
			this.radSexy = new System.Windows.Forms.RadioButton();
			this.radQuint = new System.Windows.Forms.RadioButton();
			this.radSext = new System.Windows.Forms.RadioButton();
			this.radCous = new System.Windows.Forms.RadioButton();
			this.radQuad = new System.Windows.Forms.RadioButton();
			this.lblLine2 = new System.Windows.Forms.Label();
			this.LblLine1 = new System.Windows.Forms.Label();
			this.updInit = new System.Windows.Forms.NumericUpDown();
			this.updCnt = new System.Windows.Forms.NumericUpDown();
			this.lblInit = new System.Windows.Forms.Label();
			this.lblCnt = new System.Windows.Forms.Label();
			this.btnCanx = new CSharpEx.ButtonExx();
			this.btnOK = new CSharpEx.ButtonExx();
			this.tabFndPrms.SuspendLayout();
			this.tabCmmnPrms.SuspendLayout();
			this.grpCat.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.updInit)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.updCnt)).BeginInit();
			this.SuspendLayout();
			// 
			// tabFndPrms
			// 
			this.tabFndPrms.Appearance = System.Windows.Forms.TabAppearance.Buttons;
			this.tabFndPrms.Controls.Add(this.tabCmmnPrms);
			this.tabFndPrms.Controls.Add(this.tabPage2);
			this.tabFndPrms.Controls.Add(this.tabPage3);
			this.tabFndPrms.Controls.Add(this.tabPage4);
			this.tabFndPrms.Controls.Add(this.tabPage5);
			this.tabFndPrms.Controls.Add(this.tabPage6);
			this.tabFndPrms.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.tabFndPrms.Location = new System.Drawing.Point(1, 1);
			this.tabFndPrms.Name = "tabFndPrms";
			this.tabFndPrms.SelectedIndex = 0;
			this.tabFndPrms.Size = new System.Drawing.Size(506, 410);
			this.tabFndPrms.TabIndex = 0;
			// 
			// tabCmmnPrms
			// 
			this.tabCmmnPrms.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.tabCmmnPrms.Controls.Add(this.grpCat);
			this.tabCmmnPrms.Controls.Add(this.lblLine2);
			this.tabCmmnPrms.Controls.Add(this.LblLine1);
			this.tabCmmnPrms.Controls.Add(this.updInit);
			this.tabCmmnPrms.Controls.Add(this.updCnt);
			this.tabCmmnPrms.Controls.Add(this.lblInit);
			this.tabCmmnPrms.Controls.Add(this.lblCnt);
			this.tabCmmnPrms.ForeColor = System.Drawing.Color.Navy;
			this.tabCmmnPrms.Location = new System.Drawing.Point(4, 27);
			this.tabCmmnPrms.Name = "tabCmmnPrms";
			this.tabCmmnPrms.Padding = new System.Windows.Forms.Padding(3);
			this.tabCmmnPrms.Size = new System.Drawing.Size(498, 379);
			this.tabCmmnPrms.TabIndex = 0;
			this.tabCmmnPrms.Text = "Common Primes";
			// 
			// tabPage2
			// 
			this.tabPage2.Location = new System.Drawing.Point(4, 25);
			this.tabPage2.Name = "tabPage2";
			this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage2.Size = new System.Drawing.Size(402, 381);
			this.tabPage2.TabIndex = 1;
			this.tabPage2.Text = "tabPage2";
			this.tabPage2.UseVisualStyleBackColor = true;
			// 
			// tabPage3
			// 
			this.tabPage3.Location = new System.Drawing.Point(4, 25);
			this.tabPage3.Name = "tabPage3";
			this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage3.Size = new System.Drawing.Size(402, 381);
			this.tabPage3.TabIndex = 2;
			this.tabPage3.Text = "tabPage3";
			this.tabPage3.UseVisualStyleBackColor = true;
			// 
			// tabPage4
			// 
			this.tabPage4.Location = new System.Drawing.Point(4, 25);
			this.tabPage4.Name = "tabPage4";
			this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage4.Size = new System.Drawing.Size(402, 381);
			this.tabPage4.TabIndex = 3;
			this.tabPage4.Text = "tabPage4";
			this.tabPage4.UseVisualStyleBackColor = true;
			// 
			// tabPage5
			// 
			this.tabPage5.Location = new System.Drawing.Point(4, 25);
			this.tabPage5.Name = "tabPage5";
			this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage5.Size = new System.Drawing.Size(402, 381);
			this.tabPage5.TabIndex = 4;
			this.tabPage5.Text = "tabPage5";
			this.tabPage5.UseVisualStyleBackColor = true;
			// 
			// tabPage6
			// 
			this.tabPage6.Location = new System.Drawing.Point(4, 25);
			this.tabPage6.Name = "tabPage6";
			this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage6.Size = new System.Drawing.Size(402, 381);
			this.tabPage6.TabIndex = 5;
			this.tabPage6.Text = "tabPage6";
			this.tabPage6.UseVisualStyleBackColor = true;
			// 
			// grpCat
			// 
			this.grpCat.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.grpCat.BackgroundGradientColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.grpCat.BackgroundGradientMode = CSharpEx.GroupBoxEx.GroupBoxGradientMode.None;
			this.grpCat.BorderColor = System.Drawing.Color.Navy;
			this.grpCat.BorderThickness = 3F;
			this.grpCat.Controls.Add(this.btnHlpSexy);
			this.grpCat.Controls.Add(this.btnHlpCous);
			this.grpCat.Controls.Add(this.btnHlpTrip);
			this.grpCat.Controls.Add(this.btnHlpQuin);
			this.grpCat.Controls.Add(this.btnHlpQuad);
			this.grpCat.Controls.Add(this.btnHlpSext);
			this.grpCat.Controls.Add(this.btnHlpTwin);
			this.grpCat.Controls.Add(this.radBaln);
			this.grpCat.Controls.Add(this.btnHlpBiTwin);
			this.grpCat.Controls.Add(this.radNorm);
			this.grpCat.Controls.Add(this.btnHlpAriProg);
			this.grpCat.Controls.Add(this.radAriProg);
			this.grpCat.Controls.Add(this.btnHlpNorm);
			this.grpCat.Controls.Add(this.radBiTwn);
			this.grpCat.Controls.Add(this.btnHlpSafe);
			this.grpCat.Controls.Add(this.radSafe);
			this.grpCat.Controls.Add(this.btnHlpBaln);
			this.grpCat.Controls.Add(this.radCunn);
			this.grpCat.Controls.Add(this.btnHlpCunn);
			this.grpCat.Controls.Add(this.radSoph);
			this.grpCat.Controls.Add(this.btnHlpSoph);
			this.grpCat.Controls.Add(this.radTrip);
			this.grpCat.Controls.Add(this.radTwin);
			this.grpCat.Controls.Add(this.radSexy);
			this.grpCat.Controls.Add(this.radQuint);
			this.grpCat.Controls.Add(this.radSext);
			this.grpCat.Controls.Add(this.radCous);
			this.grpCat.Controls.Add(this.radQuad);
			this.grpCat.CustomGroupBoxColor = System.Drawing.Color.White;
			this.grpCat.ForeColor = System.Drawing.Color.Navy;
			this.grpCat.GroupImage = null;
			this.grpCat.GroupTitle = "  Select  a Prime Number Category   ";
			this.grpCat.Location = new System.Drawing.Point(10, 76);
			this.grpCat.Name = "grpCat";
			this.grpCat.Padding = new System.Windows.Forms.Padding(20);
			this.grpCat.PaintGroupBox = false;
			this.grpCat.RoundCorners = 10;
			this.grpCat.ShadowColor = System.Drawing.Color.Navy;
			this.grpCat.ShadowControl = false;
			this.grpCat.ShadowThickness = 3;
			this.grpCat.Size = new System.Drawing.Size(483, 285);
			this.grpCat.TabIndex = 45;
			// 
			// btnHlpSexy
			// 
			this.btnHlpSexy.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.btnHlpSexy.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.btnHlpSexy.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnHlpSexy.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnHlpSexy.ForeColor = System.Drawing.Color.Navy;
			this.btnHlpSexy.Location = new System.Drawing.Point(14, 235);
			this.btnHlpSexy.Name = "btnHlpSexy";
			this.btnHlpSexy.Size = new System.Drawing.Size(20, 25);
			this.btnHlpSexy.TabIndex = 125;
			this.btnHlpSexy.Text = "?";
			this.btnHlpSexy.UseVisualStyleBackColor = false;
			// 
			// btnHlpCous
			// 
			this.btnHlpCous.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.btnHlpCous.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.btnHlpCous.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnHlpCous.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnHlpCous.ForeColor = System.Drawing.Color.Navy;
			this.btnHlpCous.Location = new System.Drawing.Point(14, 203);
			this.btnHlpCous.Name = "btnHlpCous";
			this.btnHlpCous.Size = new System.Drawing.Size(20, 25);
			this.btnHlpCous.TabIndex = 124;
			this.btnHlpCous.Text = "?";
			this.btnHlpCous.UseVisualStyleBackColor = false;
			// 
			// btnHlpTrip
			// 
			this.btnHlpTrip.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.btnHlpTrip.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.btnHlpTrip.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnHlpTrip.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnHlpTrip.ForeColor = System.Drawing.Color.Navy;
			this.btnHlpTrip.Location = new System.Drawing.Point(14, 75);
			this.btnHlpTrip.Name = "btnHlpTrip";
			this.btnHlpTrip.Size = new System.Drawing.Size(20, 25);
			this.btnHlpTrip.TabIndex = 123;
			this.btnHlpTrip.Text = "?";
			this.btnHlpTrip.UseVisualStyleBackColor = false;
			// 
			// btnHlpQuin
			// 
			this.btnHlpQuin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.btnHlpQuin.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.btnHlpQuin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnHlpQuin.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnHlpQuin.ForeColor = System.Drawing.Color.Navy;
			this.btnHlpQuin.Location = new System.Drawing.Point(14, 139);
			this.btnHlpQuin.Name = "btnHlpQuin";
			this.btnHlpQuin.Size = new System.Drawing.Size(20, 25);
			this.btnHlpQuin.TabIndex = 122;
			this.btnHlpQuin.Text = "?";
			this.btnHlpQuin.UseVisualStyleBackColor = false;
			// 
			// btnHlpQuad
			// 
			this.btnHlpQuad.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.btnHlpQuad.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.btnHlpQuad.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnHlpQuad.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnHlpQuad.ForeColor = System.Drawing.Color.Navy;
			this.btnHlpQuad.Location = new System.Drawing.Point(14, 107);
			this.btnHlpQuad.Name = "btnHlpQuad";
			this.btnHlpQuad.Size = new System.Drawing.Size(20, 25);
			this.btnHlpQuad.TabIndex = 121;
			this.btnHlpQuad.Text = "?";
			this.btnHlpQuad.UseVisualStyleBackColor = false;
			// 
			// btnHlpSext
			// 
			this.btnHlpSext.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.btnHlpSext.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.btnHlpSext.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnHlpSext.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnHlpSext.ForeColor = System.Drawing.Color.Navy;
			this.btnHlpSext.Location = new System.Drawing.Point(14, 171);
			this.btnHlpSext.Name = "btnHlpSext";
			this.btnHlpSext.Size = new System.Drawing.Size(20, 25);
			this.btnHlpSext.TabIndex = 126;
			this.btnHlpSext.Text = "?";
			this.btnHlpSext.UseVisualStyleBackColor = false;
			// 
			// btnHlpTwin
			// 
			this.btnHlpTwin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.btnHlpTwin.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.btnHlpTwin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnHlpTwin.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnHlpTwin.ForeColor = System.Drawing.Color.Navy;
			this.btnHlpTwin.Location = new System.Drawing.Point(14, 43);
			this.btnHlpTwin.Name = "btnHlpTwin";
			this.btnHlpTwin.Size = new System.Drawing.Size(20, 25);
			this.btnHlpTwin.TabIndex = 120;
			this.btnHlpTwin.Text = "?";
			this.btnHlpTwin.UseVisualStyleBackColor = false;
			// 
			// radBaln
			// 
			this.radBaln.AutoSize = true;
			this.radBaln.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.radBaln.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.radBaln.ForeColor = System.Drawing.Color.Navy;
			this.radBaln.Location = new System.Drawing.Point(193, 142);
			this.radBaln.Name = "radBaln";
			this.radBaln.Size = new System.Drawing.Size(84, 19);
			this.radBaln.TabIndex = 119;
			this.radBaln.TabStop = true;
			this.radBaln.Text = "Balanced";
			this.radBaln.UseVisualStyleBackColor = true;
			// 
			// btnHlpBiTwin
			// 
			this.btnHlpBiTwin.BackColor = System.Drawing.Color.DimGray;
			this.btnHlpBiTwin.Enabled = false;
			this.btnHlpBiTwin.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.btnHlpBiTwin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnHlpBiTwin.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnHlpBiTwin.ForeColor = System.Drawing.Color.Navy;
			this.btnHlpBiTwin.Location = new System.Drawing.Point(169, 235);
			this.btnHlpBiTwin.Name = "btnHlpBiTwin";
			this.btnHlpBiTwin.Size = new System.Drawing.Size(20, 25);
			this.btnHlpBiTwin.TabIndex = 118;
			this.btnHlpBiTwin.Text = "?";
			this.btnHlpBiTwin.UseVisualStyleBackColor = false;
			// 
			// radNorm
			// 
			this.radNorm.AutoSize = true;
			this.radNorm.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.radNorm.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.radNorm.ForeColor = System.Drawing.Color.Navy;
			this.radNorm.Location = new System.Drawing.Point(193, 174);
			this.radNorm.Name = "radNorm";
			this.radNorm.Size = new System.Drawing.Size(124, 19);
			this.radNorm.TabIndex = 117;
			this.radNorm.TabStop = true;
			this.radNorm.Text = "Regular Primes";
			this.radNorm.UseVisualStyleBackColor = true;
			// 
			// btnHlpAriProg
			// 
			this.btnHlpAriProg.BackColor = System.Drawing.Color.DimGray;
			this.btnHlpAriProg.Enabled = false;
			this.btnHlpAriProg.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.btnHlpAriProg.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnHlpAriProg.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnHlpAriProg.ForeColor = System.Drawing.Color.Navy;
			this.btnHlpAriProg.Location = new System.Drawing.Point(169, 203);
			this.btnHlpAriProg.Name = "btnHlpAriProg";
			this.btnHlpAriProg.Size = new System.Drawing.Size(20, 25);
			this.btnHlpAriProg.TabIndex = 116;
			this.btnHlpAriProg.Text = "?";
			this.btnHlpAriProg.UseVisualStyleBackColor = false;
			// 
			// radAriProg
			// 
			this.radAriProg.AutoSize = true;
			this.radAriProg.BackColor = System.Drawing.Color.DimGray;
			this.radAriProg.Enabled = false;
			this.radAriProg.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.radAriProg.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.radAriProg.ForeColor = System.Drawing.Color.Navy;
			this.radAriProg.Location = new System.Drawing.Point(193, 206);
			this.radAriProg.Name = "radAriProg";
			this.radAriProg.Size = new System.Drawing.Size(169, 19);
			this.radAriProg.TabIndex = 115;
			this.radAriProg.TabStop = true;
			this.radAriProg.Text = "Arithmetic Progression";
			this.radAriProg.UseVisualStyleBackColor = false;
			// 
			// btnHlpNorm
			// 
			this.btnHlpNorm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.btnHlpNorm.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.btnHlpNorm.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnHlpNorm.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnHlpNorm.ForeColor = System.Drawing.Color.Navy;
			this.btnHlpNorm.Location = new System.Drawing.Point(169, 171);
			this.btnHlpNorm.Name = "btnHlpNorm";
			this.btnHlpNorm.Size = new System.Drawing.Size(20, 25);
			this.btnHlpNorm.TabIndex = 114;
			this.btnHlpNorm.Text = "?";
			this.btnHlpNorm.UseVisualStyleBackColor = false;
			// 
			// radBiTwn
			// 
			this.radBiTwn.AutoSize = true;
			this.radBiTwn.BackColor = System.Drawing.Color.DimGray;
			this.radBiTwn.Enabled = false;
			this.radBiTwn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.radBiTwn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.radBiTwn.ForeColor = System.Drawing.Color.Navy;
			this.radBiTwn.Location = new System.Drawing.Point(193, 238);
			this.radBiTwn.Name = "radBiTwn";
			this.radBiTwn.Size = new System.Drawing.Size(113, 19);
			this.radBiTwn.TabIndex = 113;
			this.radBiTwn.TabStop = true;
			this.radBiTwn.Text = "Bi-Twin Chain";
			this.radBiTwn.UseVisualStyleBackColor = false;
			// 
			// btnHlpSafe
			// 
			this.btnHlpSafe.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.btnHlpSafe.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.btnHlpSafe.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnHlpSafe.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnHlpSafe.ForeColor = System.Drawing.Color.Navy;
			this.btnHlpSafe.Location = new System.Drawing.Point(169, 107);
			this.btnHlpSafe.Name = "btnHlpSafe";
			this.btnHlpSafe.Size = new System.Drawing.Size(20, 25);
			this.btnHlpSafe.TabIndex = 112;
			this.btnHlpSafe.Text = "?";
			this.btnHlpSafe.UseVisualStyleBackColor = false;
			// 
			// radSafe
			// 
			this.radSafe.AutoSize = true;
			this.radSafe.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.radSafe.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.radSafe.ForeColor = System.Drawing.Color.Navy;
			this.radSafe.Location = new System.Drawing.Point(193, 110);
			this.radSafe.Name = "radSafe";
			this.radSafe.Size = new System.Drawing.Size(53, 19);
			this.radSafe.TabIndex = 111;
			this.radSafe.TabStop = true;
			this.radSafe.Text = "Safe";
			this.radSafe.UseVisualStyleBackColor = true;
			// 
			// btnHlpBaln
			// 
			this.btnHlpBaln.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.btnHlpBaln.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.btnHlpBaln.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnHlpBaln.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnHlpBaln.ForeColor = System.Drawing.Color.Navy;
			this.btnHlpBaln.Location = new System.Drawing.Point(169, 139);
			this.btnHlpBaln.Name = "btnHlpBaln";
			this.btnHlpBaln.Size = new System.Drawing.Size(20, 25);
			this.btnHlpBaln.TabIndex = 110;
			this.btnHlpBaln.Text = "?";
			this.btnHlpBaln.UseVisualStyleBackColor = false;
			// 
			// radCunn
			// 
			this.radCunn.AutoSize = true;
			this.radCunn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.radCunn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.radCunn.ForeColor = System.Drawing.Color.Navy;
			this.radCunn.Location = new System.Drawing.Point(193, 78);
			this.radCunn.Name = "radCunn";
			this.radCunn.Size = new System.Drawing.Size(146, 19);
			this.radCunn.TabIndex = 109;
			this.radCunn.TabStop = true;
			this.radCunn.Text = "Cunningham Chain";
			this.radCunn.UseVisualStyleBackColor = true;
			// 
			// btnHlpCunn
			// 
			this.btnHlpCunn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.btnHlpCunn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.btnHlpCunn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnHlpCunn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnHlpCunn.ForeColor = System.Drawing.Color.Navy;
			this.btnHlpCunn.Location = new System.Drawing.Point(169, 75);
			this.btnHlpCunn.Name = "btnHlpCunn";
			this.btnHlpCunn.Size = new System.Drawing.Size(20, 25);
			this.btnHlpCunn.TabIndex = 108;
			this.btnHlpCunn.Text = "?";
			this.btnHlpCunn.UseVisualStyleBackColor = false;
			// 
			// radSoph
			// 
			this.radSoph.AutoSize = true;
			this.radSoph.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.radSoph.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.radSoph.ForeColor = System.Drawing.Color.Navy;
			this.radSoph.Location = new System.Drawing.Point(193, 46);
			this.radSoph.Name = "radSoph";
			this.radSoph.Size = new System.Drawing.Size(128, 19);
			this.radSoph.TabIndex = 107;
			this.radSoph.TabStop = true;
			this.radSoph.Text = "Sophie Germain";
			this.radSoph.UseVisualStyleBackColor = true;
			// 
			// btnHlpSoph
			// 
			this.btnHlpSoph.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.btnHlpSoph.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.btnHlpSoph.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnHlpSoph.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnHlpSoph.ForeColor = System.Drawing.Color.Navy;
			this.btnHlpSoph.Location = new System.Drawing.Point(169, 43);
			this.btnHlpSoph.Name = "btnHlpSoph";
			this.btnHlpSoph.Size = new System.Drawing.Size(20, 25);
			this.btnHlpSoph.TabIndex = 106;
			this.btnHlpSoph.Text = "?";
			this.btnHlpSoph.UseVisualStyleBackColor = false;
			// 
			// radTrip
			// 
			this.radTrip.AutoSize = true;
			this.radTrip.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.radTrip.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.radTrip.ForeColor = System.Drawing.Color.Navy;
			this.radTrip.Location = new System.Drawing.Point(40, 78);
			this.radTrip.Name = "radTrip";
			this.radTrip.Size = new System.Drawing.Size(65, 19);
			this.radTrip.TabIndex = 105;
			this.radTrip.TabStop = true;
			this.radTrip.Text = "Triplet";
			this.radTrip.UseVisualStyleBackColor = true;
			// 
			// radTwin
			// 
			this.radTwin.AutoSize = true;
			this.radTwin.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.radTwin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.radTwin.ForeColor = System.Drawing.Color.Navy;
			this.radTwin.Location = new System.Drawing.Point(40, 46);
			this.radTwin.Name = "radTwin";
			this.radTwin.Size = new System.Drawing.Size(54, 19);
			this.radTwin.TabIndex = 104;
			this.radTwin.TabStop = true;
			this.radTwin.Text = "Twin";
			this.radTwin.UseVisualStyleBackColor = true;
			// 
			// radSexy
			// 
			this.radSexy.AutoSize = true;
			this.radSexy.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.radSexy.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.radSexy.ForeColor = System.Drawing.Color.Navy;
			this.radSexy.Location = new System.Drawing.Point(40, 238);
			this.radSexy.Name = "radSexy";
			this.radSexy.Size = new System.Drawing.Size(54, 19);
			this.radSexy.TabIndex = 97;
			this.radSexy.TabStop = true;
			this.radSexy.Text = "Sexy";
			this.radSexy.UseVisualStyleBackColor = true;
			// 
			// radQuint
			// 
			this.radQuint.AutoSize = true;
			this.radQuint.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.radQuint.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.radQuint.ForeColor = System.Drawing.Color.Navy;
			this.radQuint.Location = new System.Drawing.Point(40, 142);
			this.radQuint.Name = "radQuint";
			this.radQuint.Size = new System.Drawing.Size(90, 19);
			this.radQuint.TabIndex = 103;
			this.radQuint.TabStop = true;
			this.radQuint.Text = "Quintuplet";
			this.radQuint.UseVisualStyleBackColor = true;
			// 
			// radSext
			// 
			this.radSext.AutoSize = true;
			this.radSext.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.radSext.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.radSext.ForeColor = System.Drawing.Color.Navy;
			this.radSext.Location = new System.Drawing.Point(40, 174);
			this.radSext.Name = "radSext";
			this.radSext.Size = new System.Drawing.Size(84, 19);
			this.radSext.TabIndex = 101;
			this.radSext.TabStop = true;
			this.radSext.Text = "Sextuplet";
			this.radSext.UseVisualStyleBackColor = true;
			// 
			// radCous
			// 
			this.radCous.AutoSize = true;
			this.radCous.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.radCous.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.radCous.ForeColor = System.Drawing.Color.Navy;
			this.radCous.Location = new System.Drawing.Point(40, 206);
			this.radCous.Name = "radCous";
			this.radCous.Size = new System.Drawing.Size(68, 19);
			this.radCous.TabIndex = 99;
			this.radCous.TabStop = true;
			this.radCous.Text = "Cousin";
			this.radCous.UseVisualStyleBackColor = true;
			// 
			// radQuad
			// 
			this.radQuad.AutoSize = true;
			this.radQuad.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.radQuad.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.radQuad.ForeColor = System.Drawing.Color.Navy;
			this.radQuad.Location = new System.Drawing.Point(40, 110);
			this.radQuad.Name = "radQuad";
			this.radQuad.Size = new System.Drawing.Size(95, 19);
			this.radQuad.TabIndex = 94;
			this.radQuad.TabStop = true;
			this.radQuad.Text = "Quadruplet";
			this.radQuad.UseVisualStyleBackColor = true;
			// 
			// lblLine2
			// 
			this.lblLine2.AutoSize = true;
			this.lblLine2.BackColor = System.Drawing.Color.Navy;
			this.lblLine2.ForeColor = System.Drawing.Color.Navy;
			this.lblLine2.Location = new System.Drawing.Point(2, 369);
			this.lblLine2.MaximumSize = new System.Drawing.Size(506, 3);
			this.lblLine2.MinimumSize = new System.Drawing.Size(506, 3);
			this.lblLine2.Name = "lblLine2";
			this.lblLine2.Size = new System.Drawing.Size(506, 3);
			this.lblLine2.TabIndex = 44;
			// 
			// LblLine1
			// 
			this.LblLine1.AutoSize = true;
			this.LblLine1.BackColor = System.Drawing.Color.Navy;
			this.LblLine1.ForeColor = System.Drawing.Color.Navy;
			this.LblLine1.Location = new System.Drawing.Point(2, 64);
			this.LblLine1.MaximumSize = new System.Drawing.Size(506, 3);
			this.LblLine1.MinimumSize = new System.Drawing.Size(506, 3);
			this.LblLine1.Name = "LblLine1";
			this.LblLine1.Size = new System.Drawing.Size(506, 3);
			this.LblLine1.TabIndex = 43;
			// 
			// updInit
			// 
			this.updInit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.updInit.ForeColor = System.Drawing.Color.Navy;
			this.updInit.Location = new System.Drawing.Point(316, 36);
			this.updInit.Maximum = new decimal(new int[] {
            9999999,
            0,
            0,
            0});
			this.updInit.Minimum = new decimal(new int[] {
            2,
            0,
            0,
            0});
			this.updInit.Name = "updInit";
			this.updInit.Size = new System.Drawing.Size(75, 21);
			this.updInit.TabIndex = 42;
			this.updInit.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
			// 
			// updCnt
			// 
			this.updCnt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.updCnt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.updCnt.ForeColor = System.Drawing.Color.Navy;
			this.updCnt.Location = new System.Drawing.Point(316, 7);
			this.updCnt.Maximum = new decimal(new int[] {
            16192,
            0,
            0,
            0});
			this.updCnt.Minimum = new decimal(new int[] {
            2,
            0,
            0,
            0});
			this.updCnt.Name = "updCnt";
			this.updCnt.Size = new System.Drawing.Size(75, 21);
			this.updCnt.TabIndex = 41;
			this.updCnt.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
			// 
			// lblInit
			// 
			this.lblInit.AutoSize = true;
			this.lblInit.ForeColor = System.Drawing.Color.Navy;
			this.lblInit.Location = new System.Drawing.Point(7, 42);
			this.lblInit.Name = "lblInit";
			this.lblInit.Size = new System.Drawing.Size(206, 15);
			this.lblInit.TabIndex = 40;
			this.lblInit.Text = "Enter the initial Prime Number:";
			this.lblInit.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// lblCnt
			// 
			this.lblCnt.AutoSize = true;
			this.lblCnt.ForeColor = System.Drawing.Color.Navy;
			this.lblCnt.Location = new System.Drawing.Point(7, 13);
			this.lblCnt.Name = "lblCnt";
			this.lblCnt.Size = new System.Drawing.Size(290, 15);
			this.lblCnt.TabIndex = 39;
			this.lblCnt.Text = "Enter the number of Primes you wish to find:";
			this.lblCnt.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// btnCanx
			// 
			this.btnCanx.AnimateSpeed = 12;
			this.btnCanx.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(236)))), ((int)(((byte)(239)))));
			this.btnCanx.BackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.btnCanx.BackColorEndHover = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.btnCanx.BackColorEndPress = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.btnCanx.BackColorEndUnEnable = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.btnCanx.BackColorMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
			this.btnCanx.BackColorStart = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.btnCanx.BackColorStartHover = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.btnCanx.BackColorStartPress = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.btnCanx.BackColorStartUnEnable = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.btnCanx.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
			this.btnCanx.BorderColor = System.Drawing.Color.Navy;
			this.btnCanx.BorderColorHover = System.Drawing.Color.Navy;
			this.btnCanx.BorderColorPress = System.Drawing.Color.Navy;
			this.btnCanx.BorderColorUnEnable = System.Drawing.Color.Navy;
			this.btnCanx.BorderRadius.LeftBottom = 10;
			this.btnCanx.BorderRadius.LeftTop = 10;
			this.btnCanx.BorderRadius.RightBottom = 10;
			this.btnCanx.BorderRadius.RightTop = 10;
			this.btnCanx.BottomHighlightHover = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.btnCanx.BottomHighlightNormal = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.btnCanx.BottomHighlightPress = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.btnCanx.ButtonStyle = CSharpEx.ButtonExx.ButtonStyleEnum.Customer;
			this.btnCanx.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnCanx.ForeColor = System.Drawing.Color.Navy;
			this.btnCanx.ForeColorUnEnable = System.Drawing.Color.Navy;
			this.btnCanx.ImageHover = null;
			this.btnCanx.ImageNormal = null;
			this.btnCanx.ImagePress = null;
			this.btnCanx.ImageTextPosition = CSharpEx.ButtonExx.ImageTextPositionEnum.None;
			this.btnCanx.ImageTextScale = 50;
			this.btnCanx.InnerBorderColor = System.Drawing.Color.Navy;
			this.btnCanx.InnerBorderColorHover = System.Drawing.Color.Navy;
			this.btnCanx.InnerBorderColorPress = System.Drawing.Color.Navy;
			this.btnCanx.InnerBorderColorUnEnable = System.Drawing.Color.Navy;
			this.btnCanx.Location = new System.Drawing.Point(438, 422);
			this.btnCanx.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.btnCanx.Name = "btnCanx";
			this.btnCanx.Size = new System.Drawing.Size(60, 30);
			this.btnCanx.TabIndex = 44;
			this.btnCanx.Text = "Quit";
			this.btnCanx.TopHighlightHover = System.Drawing.Color.Transparent;
			this.btnCanx.TopHighlightNormal = System.Drawing.Color.Transparent;
			this.btnCanx.TopHighlightPress = System.Drawing.Color.Transparent;
			// 
			// btnOK
			// 
			this.btnOK.AnimateSpeed = 12;
			this.btnOK.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(236)))), ((int)(((byte)(239)))));
			this.btnOK.BackColorEnd = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.btnOK.BackColorEndHover = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.btnOK.BackColorEndPress = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.btnOK.BackColorEndUnEnable = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.btnOK.BackColorMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
			this.btnOK.BackColorStart = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.btnOK.BackColorStartHover = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.btnOK.BackColorStartPress = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.btnOK.BackColorStartUnEnable = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.btnOK.BorderColor = System.Drawing.Color.Navy;
			this.btnOK.BorderColorHover = System.Drawing.Color.Navy;
			this.btnOK.BorderColorPress = System.Drawing.Color.Navy;
			this.btnOK.BorderColorUnEnable = System.Drawing.Color.Navy;
			this.btnOK.BorderRadius.LeftBottom = 10;
			this.btnOK.BorderRadius.LeftTop = 10;
			this.btnOK.BorderRadius.RightBottom = 10;
			this.btnOK.BorderRadius.RightTop = 10;
			this.btnOK.BottomHighlightHover = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.btnOK.BottomHighlightNormal = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.btnOK.BottomHighlightPress = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.btnOK.ButtonStyle = CSharpEx.ButtonExx.ButtonStyleEnum.Customer;
			this.btnOK.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnOK.ForeColor = System.Drawing.Color.Navy;
			this.btnOK.ForeColorUnEnable = System.Drawing.Color.Cyan;
			this.btnOK.ImageHover = null;
			this.btnOK.ImageNormal = null;
			this.btnOK.ImagePress = null;
			this.btnOK.ImageTextPosition = CSharpEx.ButtonExx.ImageTextPositionEnum.None;
			this.btnOK.ImageTextScale = 50;
			this.btnOK.InnerBorderColor = System.Drawing.Color.Navy;
			this.btnOK.InnerBorderColorHover = System.Drawing.Color.Navy;
			this.btnOK.InnerBorderColorPress = System.Drawing.Color.Navy;
			this.btnOK.InnerBorderColorUnEnable = System.Drawing.Color.Navy;
			this.btnOK.Location = new System.Drawing.Point(352, 422);
			this.btnOK.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
			this.btnOK.Name = "btnOK";
			this.btnOK.Size = new System.Drawing.Size(60, 30);
			this.btnOK.TabIndex = 43;
			this.btnOK.Text = "Go ...";
			this.btnOK.TopHighlightHover = System.Drawing.Color.Transparent;
			this.btnOK.TopHighlightNormal = System.Drawing.Color.Transparent;
			this.btnOK.TopHighlightPress = System.Drawing.Color.Transparent;
			// 
			// frmFndPrmCat_Tabbed
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.ClientSize = new System.Drawing.Size(508, 461);
			this.Controls.Add(this.btnCanx);
			this.Controls.Add(this.btnOK);
			this.Controls.Add(this.tabFndPrms);
			this.Name = "frmFndPrmCat_Tabbed";
			this.Text = "frmFndPrmCat_Tabbed";
			this.tabFndPrms.ResumeLayout(false);
			this.tabCmmnPrms.ResumeLayout(false);
			this.tabCmmnPrms.PerformLayout();
			this.grpCat.ResumeLayout(false);
			this.grpCat.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.updInit)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.updCnt)).EndInit();
			this.ResumeLayout(false);

			}

		#endregion

		private System.Windows.Forms.TabPage tabCmmnPrms;
		private System.Windows.Forms.TabPage tabPage2;
		private System.Windows.Forms.TabPage tabPage3;
		private System.Windows.Forms.TabPage tabPage4;
		private System.Windows.Forms.TabPage tabPage5;
		private System.Windows.Forms.TabPage tabPage6;
		public System.Windows.Forms.TabControl tabFndPrms;
		private CSharpEx.GroupBoxEx grpCat;
		private System.Windows.Forms.Button btnHlpSexy;
		private System.Windows.Forms.Button btnHlpCous;
		private System.Windows.Forms.Button btnHlpTrip;
		private System.Windows.Forms.Button btnHlpQuin;
		private System.Windows.Forms.Button btnHlpQuad;
		private System.Windows.Forms.Button btnHlpSext;
		private System.Windows.Forms.Button btnHlpTwin;
		private System.Windows.Forms.RadioButton radBaln;
		private System.Windows.Forms.Button btnHlpBiTwin;
		private System.Windows.Forms.RadioButton radNorm;
		private System.Windows.Forms.Button btnHlpAriProg;
		private System.Windows.Forms.RadioButton radAriProg;
		private System.Windows.Forms.Button btnHlpNorm;
		private System.Windows.Forms.RadioButton radBiTwn;
		private System.Windows.Forms.Button btnHlpSafe;
		private System.Windows.Forms.RadioButton radSafe;
		private System.Windows.Forms.Button btnHlpBaln;
		private System.Windows.Forms.RadioButton radCunn;
		private System.Windows.Forms.Button btnHlpCunn;
		private System.Windows.Forms.RadioButton radSoph;
		private System.Windows.Forms.Button btnHlpSoph;
		private System.Windows.Forms.RadioButton radTrip;
		private System.Windows.Forms.RadioButton radTwin;
		private System.Windows.Forms.RadioButton radSexy;
		private System.Windows.Forms.RadioButton radQuint;
		private System.Windows.Forms.RadioButton radSext;
		private System.Windows.Forms.RadioButton radCous;
		private System.Windows.Forms.RadioButton radQuad;
		private System.Windows.Forms.Label lblLine2;
		private System.Windows.Forms.Label LblLine1;
		public System.Windows.Forms.NumericUpDown updInit;
		public System.Windows.Forms.NumericUpDown updCnt;
		private System.Windows.Forms.Label lblInit;
		private System.Windows.Forms.Label lblCnt;
		private CSharpEx.ButtonExx btnCanx;
		private CSharpEx.ButtonExx btnOK;
		}
	}