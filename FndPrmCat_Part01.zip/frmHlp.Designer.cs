﻿namespace clsFndPrmCat
	{
	partial class frmHlp
		{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
			{
			if (disposing && (components != null))
				{
				components.Dispose();
				}
			base.Dispose(disposing);
			}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
			{
			this.components = new System.ComponentModel.Container();
			this.rtbHlpCat = new RichTextBoxEx.RichTextBoxEx();
			this.lblLine = new System.Windows.Forms.Label();
			this.btnOK = new CSharpEx.ButtonExx();
			this.SuspendLayout();
			// 
			// rtbHlpCat
			// 
			this.rtbHlpCat.AcceptsTab = false;
			this.rtbHlpCat.AutoWordSelection = true;
			this.rtbHlpCat.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.rtbHlpCat.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.rtbHlpCat.DetectURLs = true;
			this.rtbHlpCat.Location = new System.Drawing.Point(4, 5);
			this.rtbHlpCat.Name = "rtbHlpCat";
			this.rtbHlpCat.ReadOnly = true;
			// 
			// 
			// 
			this.rtbHlpCat.RichTextBox.AutoWordSelection = true;
			this.rtbHlpCat.RichTextBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.rtbHlpCat.RichTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.rtbHlpCat.RichTextBox.Dock = System.Windows.Forms.DockStyle.Fill;
			this.rtbHlpCat.RichTextBox.ForeColor = System.Drawing.Color.Navy;
			this.rtbHlpCat.RichTextBox.Location = new System.Drawing.Point(0, 0);
			this.rtbHlpCat.RichTextBox.Name = "rtb1";
			this.rtbHlpCat.RichTextBox.ReadOnly = true;
			this.rtbHlpCat.RichTextBox.Size = new System.Drawing.Size(553, 248);
			this.rtbHlpCat.RichTextBox.TabIndex = 1;
			this.rtbHlpCat.ShowBold = false;
			this.rtbHlpCat.ShowCenterJustify = false;
			this.rtbHlpCat.ShowColors = false;
			this.rtbHlpCat.ShowCopy = false;
			this.rtbHlpCat.ShowCut = false;
			this.rtbHlpCat.ShowFont = false;
			this.rtbHlpCat.ShowFontSize = false;
			this.rtbHlpCat.ShowItalic = false;
			this.rtbHlpCat.ShowLeftJustify = false;
			this.rtbHlpCat.ShowOpen = false;
			this.rtbHlpCat.ShowPaste = false;
			this.rtbHlpCat.ShowRedo = false;
			this.rtbHlpCat.ShowRightJustify = false;
			this.rtbHlpCat.ShowSave = false;
			this.rtbHlpCat.ShowStamp = false;
			this.rtbHlpCat.ShowStrikeout = false;
			this.rtbHlpCat.ShowToolBarText = false;
			this.rtbHlpCat.ShowUnderline = false;
			this.rtbHlpCat.ShowUndo = false;
			this.rtbHlpCat.Size = new System.Drawing.Size(555, 250);
			this.rtbHlpCat.StampAction = RichTextBoxEx.StampActions.EditedBy;
			this.rtbHlpCat.StampColor = System.Drawing.Color.Blue;
			this.rtbHlpCat.TabIndex = 0;
			this.rtbHlpCat.TabStop = false;
			// 
			// 
			// 
			this.rtbHlpCat.Toolbar.Appearance = System.Windows.Forms.ToolBarAppearance.Flat;
			this.rtbHlpCat.Toolbar.ButtonSize = new System.Drawing.Size(16, 16);
			this.rtbHlpCat.Toolbar.Divider = false;
			this.rtbHlpCat.Toolbar.DropDownArrows = true;
			this.rtbHlpCat.Toolbar.Enabled = false;
			this.rtbHlpCat.Toolbar.Location = new System.Drawing.Point(0, 0);
			this.rtbHlpCat.Toolbar.Name = "tb1";
			this.rtbHlpCat.Toolbar.ShowToolTips = true;
			this.rtbHlpCat.Toolbar.Size = new System.Drawing.Size(550, 5);
			this.rtbHlpCat.Toolbar.TabIndex = 0;
			this.rtbHlpCat.Toolbar.Visible = false;
			// 
			// lblLine
			// 
			this.lblLine.AutoSize = true;
			this.lblLine.BackColor = System.Drawing.Color.Cyan;
			this.lblLine.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.lblLine.Location = new System.Drawing.Point(2, 258);
			this.lblLine.MaximumSize = new System.Drawing.Size(563, 2);
			this.lblLine.MinimumSize = new System.Drawing.Size(563, 2);
			this.lblLine.Name = "lblLine";
			this.lblLine.Size = new System.Drawing.Size(563, 2);
			this.lblLine.TabIndex = 7;
			this.lblLine.Text = "  ";
			// 
			// btnOK
			// 
			this.btnOK.AnimateSpeed = 12;
			this.btnOK.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(236)))), ((int)(((byte)(239)))));
			this.btnOK.BackColorEnd = System.Drawing.Color.Navy;
			this.btnOK.BackColorEndHover = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
			this.btnOK.BackColorEndPress = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
			this.btnOK.BackColorEndUnEnable = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(240)))), ((int)(((byte)(243)))));
			this.btnOK.BackColorMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
			this.btnOK.BackColorStart = System.Drawing.Color.Navy;
			this.btnOK.BackColorStartHover = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
			this.btnOK.BackColorStartPress = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
			this.btnOK.BackColorStartUnEnable = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(252)))), ((int)(((byte)(254)))));
			this.btnOK.BorderColor = System.Drawing.Color.DeepSkyBlue;
			this.btnOK.BorderColorHover = System.Drawing.Color.MediumPurple;
			this.btnOK.BorderColorPress = System.Drawing.Color.OrangeRed;
			this.btnOK.BorderColorUnEnable = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(214)))), ((int)(((byte)(221)))));
			this.btnOK.BorderRadius.LeftBottom = 4;
			this.btnOK.BorderRadius.LeftTop = 4;
			this.btnOK.BorderRadius.RightBottom = 4;
			this.btnOK.BorderRadius.RightTop = 4;
			this.btnOK.BottomHighlightHover = System.Drawing.Color.Transparent;
			this.btnOK.BottomHighlightNormal = System.Drawing.Color.Transparent;
			this.btnOK.BottomHighlightPress = System.Drawing.Color.Transparent;
			this.btnOK.ButtonStyle = CSharpEx.ButtonExx.ButtonStyleEnum.QQ;
			this.btnOK.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnOK.ForeColor = System.Drawing.Color.Cyan;
			this.btnOK.ForeColorUnEnable = System.Drawing.Color.Gray;
			this.btnOK.ImageHover = null;
			this.btnOK.ImageNormal = null;
			this.btnOK.ImagePress = null;
			this.btnOK.ImageTextPosition = CSharpEx.ButtonExx.ImageTextPositionEnum.None;
			this.btnOK.ImageTextScale = 50;
			this.btnOK.InnerBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(249)))), ((int)(((byte)(251)))));
			this.btnOK.InnerBorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(86)))), ((int)(((byte)(209)))), ((int)(((byte)(255)))));
			this.btnOK.InnerBorderColorPress = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(243)))), ((int)(((byte)(246)))));
			this.btnOK.InnerBorderColorUnEnable = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(248)))), ((int)(((byte)(250)))));
			this.btnOK.Location = new System.Drawing.Point(498, 263);
			this.btnOK.Name = "btnOK";
			this.btnOK.Size = new System.Drawing.Size(50, 30);
			this.btnOK.TabIndex = 1;
			this.btnOK.Text = "OK";
			this.btnOK.TopHighlightHover = System.Drawing.Color.Transparent;
			this.btnOK.TopHighlightNormal = System.Drawing.Color.Transparent;
			this.btnOK.TopHighlightPress = System.Drawing.Color.Transparent;
			this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
			// 
			// frmHlp
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.AutoScroll = true;
			this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.ClientSize = new System.Drawing.Size(565, 301);
			this.Controls.Add(this.btnOK);
			this.Controls.Add(this.lblLine);
			this.Controls.Add(this.rtbHlpCat);
			this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.ForeColor = System.Drawing.Color.Navy;
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "frmHlp";
			this.Text = "Help for Category ";
			this.ResumeLayout(false);
			this.PerformLayout();

			}

		#endregion

		private RichTextBoxEx.RichTextBoxEx rtbHlpCat;
		private System.Windows.Forms.Label lblLine;
		private CSharpEx.ButtonExx btnOK;

		}
	}